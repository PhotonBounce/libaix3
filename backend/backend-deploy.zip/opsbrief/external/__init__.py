"""OpsBrief external package initializer."""
