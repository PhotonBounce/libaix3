"""OpsBrief task package initializer."""
