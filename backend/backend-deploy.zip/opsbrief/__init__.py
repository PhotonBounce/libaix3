"""OpsBrief package initializer."""
