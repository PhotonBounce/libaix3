"""OpsBrief services package initializer."""
